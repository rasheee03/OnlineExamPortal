package com.lti.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.interface1.GenericDAOImpl;
import com.lti.model.Course;

@Repository
public class CourseRepository extends GenericDAOImpl {
	
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	public void add(Course c)
	{
		this.entityManager.persist(c);
	}

}
