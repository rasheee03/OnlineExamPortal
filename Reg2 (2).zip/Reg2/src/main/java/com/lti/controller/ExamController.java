package com.lti.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lti.model.Question;
import com.lti.repository.QuestionPaperRepository;
import com.lti.service.ExamHistoryService;
import com.lti.service.ExamService;

@Controller
public class ExamController {

	
	@Autowired 
	private ExamHistoryService ehService;
	
	@Autowired 
	private ExamService examService;
	
	@Autowired 
	private HttpSession session;

//	@Autowired 
//	private QuestionPaperRepository quesPaperRepo;
	
	@RequestMapping(path = "exam.lti", method= RequestMethod.POST)
	public Question getQuestionPaper()
	{
		Integer opidAsAnswer;
		
		//examhistory
		//session
		
		Integer examDetail =(Integer)session.getAttribute("examNumber");
		Integer currentQuestionNumber=(Integer)session.getAttribute("questionNumber");
		if(currentQuestionNumber==null)
		{
			currentQuestionNumber=1;
			
		}
		
		else
		{
			//forward
			currentQuestionNumber=currentQuestionNumber+1;
		}
		
		
		session.setAttribute("questionNumber", currentQuestionNumber);
		String action="next";
		Question question = examService.findQuestion(examDetail, action, currentQuestionNumber);
		System.out.println("examNumber" + examDetail);
		return question;
		
		
		
	}
}
