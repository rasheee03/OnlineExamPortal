package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.model.Question;
import com.lti.repository.ExamHistoryRepository;
import com.lti.repository.QuestionPaperRepository;

@Service
public class ExamService {

	
	@Autowired
	private ExamHistoryRepository ehRepo;
	
	@Autowired
	private QuestionPaperRepository qpRepo;
	
	public Question findQuestion(int examDetail, String action, int currentQuestionNumber)
	{
		List<Question> question = qpRepo.fetchQuestionsByExam(examDetail);
		int counter =0;
		for(Question q1 : question )
		{
			counter= counter+1;
			if(counter== currentQuestionNumber)
			{
				return q1;
			}
			
			if(counter== question.size())
			{
				return null;
			}
			else 
				{	System.out.println("question---->"+q1.getQid());	}
		}
				return null;
	}
}
