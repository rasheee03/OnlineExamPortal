package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.Course;
import com.lti.model.ExamHistory;
import com.lti.model.Login;
import com.lti.model.Question;
import com.lti.model.QuestionPaper;
import com.lti.repository.CourseRepository;
import com.lti.repository.ExamHistoryRepository;
import com.lti.repository.LoginRepository;
import com.lti.repository.QuestionPaperRepository;
import com.lti.repository.QuestionRepository;

@Service
public class QuestionPaperService {

	@Autowired
	private QuestionPaperRepository quesPaperRepo; 
	
	@Autowired
	private LoginRepository loginRepo;
	
	@Autowired
	private CourseRepository courseRepo;
	
	@Autowired
	private ExamHistoryRepository ehRepo;
	
	@Autowired
	private QuestionRepository quesRepo; 

	
	@Transactional
	public int addNewQuestionPaperForTest(int courseId, int userId)
	{
		Login login = (Login) loginRepo.findById(Login.class,userId);
		Course course = (Course) courseRepo.findById(Course.class,userId);
		
		ExamHistory examHistory = new ExamHistory();
		examHistory.setLogin(login);
		examHistory.setCourse(course);
		examHistory = (ExamHistory) ehRepo.save(examHistory);
		examHistory.setExamDate(new java.util.Date());
		
		//set level1 questions
		
		
		addQuestions(1,examHistory);
		addQuestions(2,examHistory);
		addQuestions(3,examHistory);
		return examHistory.getEid();

	}
	
	
	public void addQuestions(int level, ExamHistory examHistory)
	{
		List<Question> list = quesRepo.findByLevel(level);
		
		for(Question question : list)
		{
			QuestionPaper questionPaper = new QuestionPaper();
			questionPaper.setExamHistory(examHistory);
			questionPaper.setQuestion(question);
			quesPaperRepo.save(questionPaper);
		}
	}
	
	public List<Question> fetchQuestions(int c){
		return quesPaperRepo.fetchQuestions(c);
	}
}
