package com.lti.interface1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public interface GenericDAO{

	Object save(Object newInstance);
	Object update(Object obj);
	
	void delete(Object obj);
	Object findById(Class class1, Object id);
//	Long findCount();
//	
//	List<E> findAll;
//	
//	public List<PK> findAllIds;
//	
	
}
