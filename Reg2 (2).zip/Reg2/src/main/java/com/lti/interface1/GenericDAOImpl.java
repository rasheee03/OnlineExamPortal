package com.lti.interface1;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;

public class GenericDAOImpl implements GenericDAO {

	@Autowired
	private EntityManager entityManager;
	
	public Object save(Object newInstance) {
		entityManager.persist(newInstance);
		entityManager.flush();
		entityManager.refresh(newInstance);
		return newInstance;
	}

	public Object update(Object obj) {
		obj = entityManager.merge(obj); 
		return obj;
	}

	public void delete(Object obj) {
		entityManager.remove(obj);
		entityManager.flush();
	}

	public Object findById(Class class1, Object id) {
		
		return (Object)entityManager.find(class1, id);
	}
	
//	public List<E> findAll() {
//		
//		Query q = entityManager.createQuery(String.format("select obj from %s as obj", entityClass.getName()));
//		return q.getResultList();
//}
//
//	public Long findCount() {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
