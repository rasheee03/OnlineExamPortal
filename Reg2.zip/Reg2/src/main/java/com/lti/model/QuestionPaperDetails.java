package com.lti.model;

public class QuestionPaperDetails {

}
