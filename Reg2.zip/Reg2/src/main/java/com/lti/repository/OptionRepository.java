package com.lti.repository;

import org.springframework.stereotype.Repository;

import com.lti.model.Option;

@Repository
public class OptionRepository {
	
	
	public void add(Option o)

	{
		
	}
}
